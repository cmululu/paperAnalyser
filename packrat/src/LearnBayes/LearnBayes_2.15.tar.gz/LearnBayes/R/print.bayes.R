print.bayes=function(x,...)
  x$prob